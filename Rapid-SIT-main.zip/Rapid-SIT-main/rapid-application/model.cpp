#include <iostream>
#include <fasttext/fasttext.h>
#include <sstream>

#include "include/model.h"

using namespace std;

string training_file = "./training_data.txt";

// void model_train() {
//     fasttext::FastText ft;

//     fasttext::Args args;
//     args.input = training_file;
//     // args.epoch = 50;
//     // args.lr = 1.0;
//     // args.wordNgrams = 5;
//     // args.dim = 300;
//     // args.ws = 10;

//     ft.train(args);
//     ft.saveModel(model_file);
// }

vector<pair<fasttext::real, string>> model_predict(const fasttext::FastText& ft, string query) {
    // fasttext::FastText ft;

    // cout << "Loading model...\n";
    // ft.loadModel(model_file);

    istringstream inStream(query);

    vector<pair<fasttext::real, string>> predictions;

    // cout << "Running prediction for query (" << query << ")\n";
    ft.predictLine(inStream, predictions, 2, 0.1);

    return predictions;
}

// int main() {
//     // model_train();
//     fasttext::FastText ft;

//     cout << "Loading model...\n";

//     ft.loadModel(model_file);

//     auto predictions = model_predict(ft, "how do q5 ah");

//     for (const auto& p : predictions) {
//         cout << "Label: " << p.second << "\nProbability: " << p.first << endl;
//     }

//     return 0;
// }