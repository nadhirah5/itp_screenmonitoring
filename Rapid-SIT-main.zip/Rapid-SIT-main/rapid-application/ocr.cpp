#include <iostream>
#include <string>
#include <fstream>

#include <tesseract/baseapi.h>
#include <leptonica/allheaders.h>

#include "include/ocr.h"

using namespace std;

tesseract::TessBaseAPI* tesseract_api_setup() {
    tesseract::TessBaseAPI* api = new tesseract::TessBaseAPI();

    // Initialize tesseract-ocr with English, without specifying tessdata path
    if (api->Init(NULL, "eng")) {
        fprintf(stderr, "Could not initialize tesseract.\n\n");
        exit(1);
    }

    return api;
}

// file_path eg.: ../processed_images/telegram1/roi_telegram1_13.png
string tesseract_ocr(tesseract::TessBaseAPI* api, char* file_path, string file) {
    try {
        char* outText;

        //cout << "Setting image for Tesseract API...\n";
        // Open input image with leptonica library
        Pix* image = pixRead(file_path);
        api->SetImage(image);

        //cout << "Performing OCR...\n\n";

        // Get OCR result
        outText = api->GetUTF8Text();
        //printf("OCR output:\n%s", outText);

        if (strlen(outText) != 0) {
            string new_file_path = file_path;
            new_file_path.erase(0, 28 + file.length()); // removing dir prefix
            new_file_path.erase(new_file_path.size() - 4); // removing original path's .png
            new_file_path = "../output/text_output/" + file + "/" + "output_" + new_file_path + ".txt";

            ofstream fw(new_file_path, std::ofstream::out);

            if (fw.is_open())
                fw << outText;
            fw.close();

            delete[] outText;
            pixDestroy(&image);

            // Remove all empty lines from the file.
            std::ifstream is(new_file_path);
            std::ofstream ofs;
            ofs.open(new_file_path + ".tmp", std::ofstream::out);

            std::string line;
            std::vector<std::string> lines;
            while(getline(is, line)) {
                if (!line.empty()) {
                    lines.push_back(line);
                }
            }
            is.close();

            // write all lines except last if last is empty
            for(size_t i = 0; i < lines.size(); ++i) {
                if(i == lines.size() - 1 && lines[i].empty())
                    break;
                ofs << lines[i];
                if(i != lines.size()-1)
                    ofs << "\n";
            }

            ofs.close();

            // Rename temporary file
            std::rename((new_file_path + ".tmp").c_str(), new_file_path.c_str());

            return new_file_path;
        }

        return "None";
    }
    catch (const std::exception& e) {
        std::cerr << "Caught exception: " << e.what() << '\n';

        return "Failure";
    }
    
    return "Failure";
}

void tesseract_free_api(tesseract::TessBaseAPI* api) {
    // Destroy used object and release memory
    api->End();
    //cout << "Tesseract API has been freed.\n\n";
}
