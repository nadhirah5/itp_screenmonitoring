#include <iostream>
#include <vector>
#include <string>
#include <fstream>

#include <thread>
#include <chrono>

#include <tesseract/baseapi.h>
#include <leptonica/allheaders.h>
#include <fasttext/fasttext.h>

// #include "include/image_manipulation.h"
#include "include/ocr.h"
#include "include/model.h"
// #include "include/text_analyser.h"

#include <sstream>

using namespace std;

int main(int argc, char* argv[]) {
    if (argc <= 1) {
        cout << "Please input something.\n";
        return 0;
    }
    else {
        #pragma region OCR

        int num_files;
        istringstream iss(argv[1]);
        
        if (iss >> num_files) {
            string file = argv[2];

            tesseract::TessBaseAPI* tesseract_api = tesseract_api_setup(); // Setup Tesseract API

            fasttext::FastText ft;
            // cout << "Loading model...\n";
            ft.loadModel("../rapid-application/model6.bin");

            for (int i = 0; i < num_files; i++) {
                    string file_to_test = "../output/processed_images/" + file + "/roi_" + file + "_" + to_string(i) + ".png";

                    // string greyscaled_file_path = binarise_image((char*)&file_to_test[0]); // Try to greyscale image

                    // // If greyscaling image failed
                    // if (greyscaled_file_path == "Failure") 
                    //     return 0;

                    string output_file_path = tesseract_ocr(tesseract_api, (char*)&file_to_test[0], file); // Try to perform OCR on image

                    // If OCR passed and text detected
                    if (output_file_path != "Failure" && output_file_path != "None") {
                        string line;
                        ifstream output_file(output_file_path);
                        if (output_file.is_open()) {
                            while (getline(output_file, line)) {
                                auto predictions = model_predict(ft, line);

                                for (const auto& p : predictions) {
                                    cout << file_to_test << "\n" << line << "\n" << p.second << "\n"  << p.first << "\n"; // roi, query, label, probability
                                }
                            }
                        }
                    }
            }
            tesseract_free_api(tesseract_api); // Free Tesseract API
        }
        
        #pragma endregion OCR
    }
    return 0;
}