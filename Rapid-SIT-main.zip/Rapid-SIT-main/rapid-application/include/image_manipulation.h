#pragma once

#ifndef IMAGE_MANIPULATION_H
#define IMAGE_MANIPULATION_H

std::string binarise_image(char* file_path);

#endif