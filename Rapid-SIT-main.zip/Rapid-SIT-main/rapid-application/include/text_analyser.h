#pragma once

#ifndef TEXT_ANALYSER_H
#define TEXT_ANALYSER_H

int analyse_text(std::string file_path);

#endif