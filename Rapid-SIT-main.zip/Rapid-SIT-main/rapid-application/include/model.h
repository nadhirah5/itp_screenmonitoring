#pragma once

#ifndef MODEL_H
#define MODEL_H

std::vector<std::pair<fasttext::real, std::string>> model_predict(const fasttext::FastText& ft, std::string query);

#endif