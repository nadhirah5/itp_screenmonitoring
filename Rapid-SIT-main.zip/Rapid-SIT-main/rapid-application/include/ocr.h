#pragma once

#ifndef OCR_H
#define OCR_H

tesseract::TessBaseAPI* tesseract_api_setup();
std::string tesseract_ocr(tesseract::TessBaseAPI* api, char* file_path, std::string file);
void tesseract_free_api(tesseract::TessBaseAPI* api);

#endif