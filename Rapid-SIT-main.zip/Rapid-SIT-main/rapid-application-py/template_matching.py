import cv2
# import numpy as np
import math
import os

template_folder = "../templates"

def run_template_match(image):
    # print(image)
    print(f"Matching templates for {image}")
    # Load the source image and the template image
    source = cv2.imread(image, 0)

    # Construct object for returning later
    parts = image.rsplit('/', 1)
    initial_object = {
        "image_name": f"{parts[1]}"
    }

    # compare image to telegram templates
    for template in os.listdir(template_folder):
        print(f"Matching to {template} ...")
        curr_template = cv2.imread(template_folder + "/" + template, 0)
        initial_object[f"{template[:-4]}"] = template_match(source, curr_template)
            
    print(f"Completing matching templates for {image}")

    return initial_object


def template_match(image, template):
    # Get the dimensions of the template image
    # w, h = template.shape[::-1]

    # Apply template Matching
    res = cv2.matchTemplate(image, template, cv2.TM_CCOEFF_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)

    print(f"Value: {max_val} \n")  # This should be above threshold if template is found

    # Set the threshold value
    threshold = 0.7

    # no match
    if threshold >= max_val:
        return False

    # match
    return True

    # loc = np.where(res >= threshold)
    #
    # # Draw a rectangle around the matched region
    # for pt in zip(*loc[::-1]):
    #     cv2.rectangle(source, pt, (pt[0] + w, pt[1] + h), (255, 0, 255), 2)
    #
    # resized_image = cv2.resize(source, (1200, 800))  # You can adjust the resolution as needed
    # cv2.imshow('Image', resized_image)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()