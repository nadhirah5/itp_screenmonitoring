import cv2
import os


def generate_roi(file):
    print(file)
    print(f"Generating ROI for {file}...")
    # Load the image in color
    image = cv2.imread(file)

    file = file[22:-4]

    path = f'../output/processed_images/{file}'
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        print("Creation of the directory %s failed" % path)
    else:
        print("Successfully created the directory %s " % path)

    # Resize the image
    height, width, _ = image.shape
    resize_ratio = 1
    resized_image = cv2.resize(image, (int(width * resize_ratio), int(height * resize_ratio)))

    # Convert to grayscale for edge detection and thresholding
    gray = cv2.cvtColor(resized_image, cv2.COLOR_BGR2GRAY)

    # Apply Gaussian blur
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Apply Canny Edge detection
    edges = cv2.Canny(blurred, 100, 200)

    # Dilate the edges image to close gaps between lines of text
    dilated_edges = cv2.dilate(edges, None, iterations=9)

    # Find contours
    contours, _ = cv2.findContours(dilated_edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    counter = 0
    for contour in contours:
        # Get bounding box
        x, y, w, h = cv2.boundingRect(contour)

        # Calculate corners
        top_left = (x, y)
        top_right = (x + w, y)
        bottom_right = (x + w, y + h)
        bottom_left = (x, y + h)

        if h < w - 35 or h > w + 35:
            # Extract region of interest from the color image
            roi = resized_image[y:y + h, x:x + w]

            # print(f"{file} counter {counter}: {x}, {y}, {w}, {h}")

            # Save ROI as image
            cv2.imwrite(f'../output/processed_images/{file}/roi_{file}_{counter}.png', roi)
            counter += 1

    print(f"Completing ROI for {file}")

    return file, counter
