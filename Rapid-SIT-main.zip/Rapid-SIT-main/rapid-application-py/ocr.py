import subprocess
import os

os.environ['TESSDATA_PREFIX'] = '../../Tesseract-OCR/tessdata'


def perform_ocr(file, count):
    print(f"Starting OCR for {file}...")
    path_to_app = r'../rapid-application/main'
    args = [f'{count}', f'{file}']

    path = f'../output/text_output/{file}'
    try:
        os.makedirs(path, exist_ok=True)
    except OSError:
        print("Creation of the directory %s failed" % path)
    else:
        print("Successfully created the directory %s " % path)

    result = subprocess.run([path_to_app] + args, capture_output=True, text=True)

    lines = result.stdout.split('\n')  # Split the output into lines

    print(f"Completed OCR for {file}")

    return lines

    # return initial_object
