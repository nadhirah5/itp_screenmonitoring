# import fasttext

# def model_get(path):
#     return fasttext.load_model(path)

# def model_query(model, query):
#     predictions = 2
#     query_object = {
#         "query": "",
#         "probabilities": {}
#     }

#     labels, probabilities = model.predict(query, k=predictions)
#     for i in range(0, predictions):
#         query_object["query"] = query
#         query_object["probabilities"][f"{labels[i][9:]}"] = probabilities[i]
        
#     return query_object