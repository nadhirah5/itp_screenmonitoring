from datetime import datetime

from ocr import *
from roi import *
from template_matching import *
# from pre_model import *
# from post_model import*

import time
import json

training = "training_data.txt"
validation = "validation_data.txt"

files = []

image_directory = "../output/image_store"
for image_file in os.listdir(image_directory):
    files.append(f"{image_directory}/{image_file}")


def main():
    start_time_first = time.time()

    final_object = []

    for f in files:
        start_time_1 = time.time()
        initial_object = run_template_match(f)
        end_time_1 = time.time()
        print(f"Template matching ran for {end_time_1 - start_time_1} seconds\n")

        start_time_2 = time.time()
        file, count = generate_roi(f)
        end_time_2 = time.time()
        print(f"ROI generation ran for {end_time_2 - start_time_2} seconds\n")

        start_time_3 = time.time()
        lines = perform_ocr(file, count)
        end_time_3 = time.time()
        print(f"OCR ran for {end_time_3 - start_time_3} seconds\n")

        start_time_4 = time.time()
        # initial_object["flagged_roi"] = []
        initial_object["queries"] = []

        roi_paths = set()

        # for each file
        for i in range(0, len(lines), 4):
            if lines[i].strip():  # This will ensure the string isn't empty or just whitespace
                roi_paths.add(lines[i])

                initial_object["queries"].append({
                    "processed_image": f"flagged_{lines[i].rsplit('/', 1)[1]}" ,
                    "query": lines[i+1] if i+1 < len(lines) else None,
                    "label": lines[i+2] if i+2 < len(lines) else None,
                    "probability": lines[i+3] if i+3 < len(lines) else None,
            })

        for roi_path in roi_paths:
            roi_parts = roi_path.rsplit('/', 1)
            new_roi_path = roi_parts[0] + '/flagged_' + roi_parts[1]
            # initial_object["flagged_roi"].append(f"flagged_{roi_parts[1]}")
            os.rename(roi_path, new_roi_path)

            text_path = roi_path.replace("processed_images", "text_output")
            text_path = text_path.replace(".png", ".txt")
            index = text_path.rfind('/')
            text_path = text_path[:index+1] + 'output_' + text_path[index+1:]

            text_parts = text_path.rsplit('/', 1)
            new_text_path = text_parts[0] + '/flagged_' + text_parts[1]
            os.rename(text_path, new_text_path)

        final_object.append(initial_object)
        end_time_4 = time.time()
        print(f"Handling final object ran for {end_time_4 - start_time_4} seconds\n")

    os.makedirs('../output/json', exist_ok=True)
    timestamp = datetime.now().replace(microsecond=0).isoformat()
    timestamp = timestamp.replace(':', '-')

    with open(f'../output/json/{timestamp}_{file}.json', 'w') as json_file:
        json.dump(final_object, json_file, indent=4)

    os.rename(f, f"../output/processed_images/{f[22:-4]}/{timestamp}_{f[22:]}")

    end_time_last = time.time()
    print(f"Program ran for {end_time_last - start_time_first} seconds")

if __name__ == "__main__":
    main()