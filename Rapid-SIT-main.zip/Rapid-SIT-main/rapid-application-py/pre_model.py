# import fasttext
# import numpy as np

# def model_train(train_path, validation_path):
#     print("Starting training for model...")
#     model = fasttext.train_supervised(input=train_path, lr=0.5, dim=250, epoch=50, ws=5)
#     print("Testing model...")
#     print(model.test(validation_path))

#     return model

# def model_save(model, output_path):
#     print("Saving model...")
#     model.save_model(output_path)


# model = model_train("training_data.txt", "validation_data.txt")
# model_save(model, "model2.bin")

# print(model.words)

# results = model.predict("Will be sending the documents and figma link later on, currently", k=2, threshold=0.1)
# labels, probabilities = results

# for label, probability in zip(labels, probabilities):
#     print(f"label: {label}")
#     print(f"probability: {probability:.8f}")