# Rapid-SIT - A project for the greater good
### Rapid SIT aims to eliminate the prevalence of cheating in online assessments via technologies such as template matching, image segmentation, OCR, and text classification.

## Pre-requisites
### Formatting SD Card (requires SD card reader)
- You can skip this section if the SD card is already formatted
- File System: FAT32
- Allocation Unit Size: 8192B (for 16GB SD Card)
- For any formatting errors, refer to [this guide](https://www.icare-recovery.com/howto/diskpart-format-sd-card-repair.html)

### Installing Raspberry Pi OS on SD Card 
1) Download [Raspberry Pi Imager](https://www.raspberrypi.com/software/)
2) Launch Raspberry Pi Imager
3) Select **Raspberry Pi OS (32-bit)**
4) Select storage of SD card
5) In options (gear icon)
    - Image customisation options (to always use)
    - Enable SSH (Use password authentication)
    - Set username and password ("pi" and "raspberry" respectively)
    - Set locale settings (Asia/Singapore, us)
    - Click "Save"
6) Click "WRITE" (this process takes awhile)
7) Click "Yes" to "Are you sure ..."

### On your Raspberry Pi 3 (RP3)
### Setting up RP3 and retrieving IP Address
8) Connect your peripherals (SD card, mouse, keyboard, monitor via HDMI) to the RP3
9) Plug in the power supply for the RP3, wait 3 - 5 minutes for it to boot
10) Connect to the same WiFi or network as your PC, via the network icon on the top right (in between bluetooth and sound icons)
    - Turn on Wireless LAN
    - Connect to the desired network
11) Click on terminal or command prompt icon on the top left
12) Retrieve RP3's **IP Address** with the command below
    - Note: you can skip this step if you do not intend to work remotely (via SSH on your own device)
```
hostname -I
```
Example IP Output of Step 12:
```
192.168.1.120
```

## Installation of Rapid SIT
### On the RP3 **(preferred way)**
13) On the terminal, cd into Desktop
```
cd /home/pi/Desktop
```
14) Download the setup file (see command below)
```
wget -O setup.sh https://shorturl.at/qDFPY
```
15) Run setup.sh (see command below)
```
sudo sh setup.sh
```

### ALTERNATIVE: On your personal device (Windows)
13b) On PowerShell, SSH into the RP3 (see command below, replace **YourIPHere** with the IP from step 9)
```
ssh pi@YourIPHere
```
14b) cd into Desktop
```
cd /home/pi/Desktop
```
15b) Download the setup file (see command below)
```
wget -O setup.sh https://shorturl.at/qDFPY
```
16b) Run setup.sh (see command below)
```
sudo sh setup.sh
```
